library(testthat)
library(lab4)

test_check("lab4")
